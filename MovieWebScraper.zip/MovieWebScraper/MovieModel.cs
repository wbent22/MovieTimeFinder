﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MovieWebScraper
{
    class MovieModel
    {
        public string Title { get; set; }
        public List<string> times = new List<string>();
    }
}
