﻿using HtmlAgilityPack;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Text;
using System.Web;

namespace MovieWebScraper
{
    class Scraper
    {
        private ObservableCollection<MovieModel> _entries = new ObservableCollection<MovieModel>();

        private ObservableCollection<MovieModel> _movie = new ObservableCollection<MovieModel>();



        public ObservableCollection<MovieModel> Entries
        {
            get { return _entries; }
            set { _entries = value; }
        }

        public void ScrapeFatCatData(string page)
        {
            var web = new HtmlWeb();
            var doc = web.Load(page);


            var HarMovies = doc.DocumentNode.SelectNodes("//div[@class = 'mnw_right']");
            var ShowTimes = doc.DocumentNode.SelectNodes("//*[@class = 'doly_atm_box']");

            foreach (var movie in HarMovies)
            {
                var header = HttpUtility.HtmlDecode(movie.SelectSingleNode(".//h2[@class = 'movie_title']").InnerText);
                List<string> Times = new List<string>();

                foreach (var time in ShowTimes)
                {
                    
                    var thistime = HttpUtility.HtmlDecode(time.SelectSingleNode("//*[@id='movie_now_showing']/div[1]/div[3]/div[2]/div/ul/li[1]/a").InnerText);
                    Times.Add(thistime);
                }
                Console.WriteLine(Times);
                _entries.Add(new MovieModel { Title = header, times = Times });
                
            }
        }


        public ObservableCollection<MovieModel> Movies
        {
            get { return _movie; }
            set { _movie = value; }
        }

        public void ScrapeMovieData(string page)
        {
            var web = new HtmlWeb();
            var doc = web.Load(page);


            var node = doc.DocumentNode.SelectSingleNode("//*[@class = 'movies']");
            var movies = node.SelectNodes("//*[@class = 'cols']");
            
            foreach (var movie in movies)
            {
                movie.InnerText.
                //var header = HttpUtility.HtmlDecode(movie.SelectSingleNode("//*[@id='theatre - detail - container']/div[3]/div/ul/li[2]/div[1]/div[2]/h2").InnerText);
                //_movie.Add(new MovieModel { Title = header });

                Debug.WriteLine(movie.InnerText);
            }
            {

            }
            //foreach (var movie in HarMovies)
            {
                //Console.WriteLine(movie.InnerText);

                //".//div[@class = 'text-right _1hazOxgsUXq0rb-UgDZwNp _2FulmH3iQ5Kp8yQh0HAxic _36FIyjphKz71izCg1N-Uks']"
            }
        }
    }
}
